package com.aws.jp.web.test.api.ui.sales;

import java.math.BigDecimal;
import java.util.Objects;

import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PostSalesResponse {
  @NotNull private final String name;

  private final Integer amount;

  private BigDecimal price;

  public PostSalesResponse(String name, Integer amount, BigDecimal price) {
    this.name = name;
    this.amount = amount;
    // 整数の場合は整数として表示する
    if ((Objects.nonNull(price)) && (price.doubleValue() % 1 == 0)) {
      this.price = price.setScale(0);
    } else {
      this.price = price;
    }
    ValidateHelper.validate(this);
  }
}
