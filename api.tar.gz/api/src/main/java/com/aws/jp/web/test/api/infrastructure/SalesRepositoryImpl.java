package com.aws.jp.web.test.api.infrastructure;

import java.util.Objects;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.web.context.annotation.ApplicationScope;

import com.aws.jp.web.test.api.domain.Sales;
import com.aws.jp.web.test.api.domain.SalesRepository;

import lombok.RequiredArgsConstructor;

@Repository
@ApplicationScope
@RequiredArgsConstructor
public class SalesRepositoryImpl implements SalesRepository {
  @PersistenceContext private EntityManager manager;

  @Override
  public Optional<Sales> findByCustomerId(String customerId) {
    final SalesEntity entity = manager.find(SalesEntity.class, customerId);
    return Objects.nonNull(entity) ? Optional.of(entity.convert()) : Optional.empty();
  }

  @Override
  public Sales create(Sales sales) {
    final SalesEntity entity = SalesEntity.of(sales);
    manager.persist(entity);
    return entity.convert();
  }

  @Override
  public Sales update(Sales sales) {
    final SalesEntity entity = SalesEntity.of(sales);
    manager.merge(entity);
    return entity.convert();
  }

  @Override
  public void deleteAll() {
    manager.createNamedQuery("deleteAllSales").executeUpdate();
  }
}
