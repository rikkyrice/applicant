package com.aws.jp.web.test.api.domain;

import java.util.Optional;

import com.aws.jp.web.test.api.domain.query.SortCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryResult;

public interface StockRepository {

  // 商品在庫をクエリ検索
  StockQueryResult query(StockQueryCondition condition, SortCondition pCondition);
  
  // 商品名をキーとして在庫を取得
  Optional<Stock> findByName(String name);

  // 在庫を作成
  Stock create(Stock stock);

  // 在庫を更新
  Stock update(Stock stock);

  // 全削除
  void deleteAll();
}
