package com.aws.jp.web.test.api.ui.sales;

import java.math.BigDecimal;
import java.net.URI;
import java.util.Objects;

import javax.inject.Inject;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.aws.jp.web.test.api.application.SalesService;
import com.aws.jp.web.test.api.application.StocksService;
import com.aws.jp.web.test.api.common.log.Logging;
import com.aws.jp.web.test.api.domain.Sales;
import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.ui.validation.BeanValidateHelper;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("sales")
@RequiredArgsConstructor
public class SalesResource {
  @Inject private final StocksService stockService;
  @Inject private final SalesService salesService;

  /** 販売 */
  @PostMapping(
      produces = { "application/json" })
  @Logging
  public ResponseEntity<PostSalesResponse> post(
      @RequestBody PostSalesRequestBody body,
      UriComponentsBuilder uriComponentsBuilder) {
    
    // リクエストボディの入力チェック
    BeanValidateHelper.validate(body);
    
    // 在庫情報を更新
    final Stock stock = stockService.buy(body.getStock());
    // リクエストボディから価格を取得
    final BigDecimal price = body.getPrice();
    // 価格がnullでない場合は売り上げを作成
    if (Objects.nonNull(price)) {
      // 今回の要件ではユーザーによる売上の管理はないので、仮に"aws"というユーザーによる要求として処理
      final String customerId = "aws";
      salesService.post(customerId, body.getStock().getAmount(), price);
    }

    // ロケーションを作成
    final URI location = uriComponentsBuilder
        .path("vi/stocks/{name}")
        .buildAndExpand(stock.getName())
        .toUri();
    final HttpHeaders headers = new HttpHeaders();
    headers.setLocation(location);

    return new ResponseEntity<PostSalesResponse>(new PostSalesResponse(body.getName(), body.getAmount(), price), headers, HttpStatus.OK);
  }

  /** 売上チェック */
  @GetMapping(
      produces = { "application/json" })
  @Logging
  public ResponseEntity<SalesResponse> getTotalSales() {

    // 今回の要件では"aws"ユーザーの売上のみ考慮するため、"aws"を指定
    final String customerId = "aws";
    // 売り上げをユーザーIDをキーにして取得
    final Sales response = salesService.getByName(customerId);

    return new ResponseEntity<SalesResponse>(new SalesResponse(response), HttpStatus.OK);
  }
}
