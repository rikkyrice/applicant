package com.aws.jp.web.test.api.ui.sales;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.aws.jp.web.test.api.domain.Sales;

import lombok.Getter;

@Getter
public class SalesResponse {
  // 小数の指定に対応するためBigDecimalを定義
  @NotNull private final BigDecimal sales;

  public SalesResponse(Sales sales) {
    final BigDecimal priceBd = sales.getPrice();
    // 小数第三位を切り上げて第二位までを保持するように指定
    this.sales = priceBd.setScale(2, RoundingMode.CEILING);
    ValidateHelper.validate(this);
  }
}
