package com.aws.jp.web.test.api.ui.stocks;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Optional;

import javax.inject.Inject;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.aws.jp.web.test.api.application.SalesService;
import com.aws.jp.web.test.api.application.StocksService;
import com.aws.jp.web.test.api.common.log.Logging;
import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.domain.query.SortCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryResult;
import com.aws.jp.web.test.api.ui.validation.BeanValidateHelper;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("stocks")
@RequiredArgsConstructor
public class StocksResource {
  @Inject private final StocksService stockService;
  @Inject private final SalesService salesService;

  /** 在庫の更新、作成API */
  @PostMapping(
      produces = { "application/json" })
  @Logging
  public ResponseEntity<PostStockResponse> post(
      @RequestBody PostStockRequestBody body,
      UriComponentsBuilder uriComponentsBuilder) {
    
    // リクエストボディの入力チェック
    BeanValidateHelper.validate(body);
    
    // 在庫更新、作成実行
    // リクエストボディはドメイン層の在庫オブジェクトに変換
    final Stock response = stockService.post(body.convert());

    // ロケーションを作成
    final URI location = uriComponentsBuilder
        .path("vi/stocks/{name}")
        .buildAndExpand(response.getName())
        .toUri();
      
    final HttpHeaders headers = new HttpHeaders();
    headers.setLocation(location);

    return new ResponseEntity<PostStockResponse>(new PostStockResponse(body.getName(), body.getAmount()), headers, HttpStatus.OK);
  }

  /** 在庫取得API */
  @GetMapping(
      value = {"", "{name}"},
      produces = { "application/json" })
  @Logging
  public ResponseEntity<LinkedHashMap<String, Integer>> getStocks(
      @PathVariable("name") Optional<String> params1) {

    // パスパラメーターが存在する場合は、nameをキーにした在庫取得を実行
    if (params1.isPresent()) {
      final Stock response = stockService.get(params1.get());
      return new ResponseEntity<LinkedHashMap<String, Integer>>(new StocksResponse(response).getStockMap(), HttpStatus.OK);
    }
    // クエリオブジェクトを作成
    // 今後の機能追加に柔軟に対応するためにビルダーを実装、今回は在庫が1つ以上存在する商品を取得するため在庫の最少数1を格納
    final StockQueryCondition condition = StockQueryCondition.builder().min(1).build();
    // ソート要件は今後も増えることを考慮し、ソートキーと順序を自由に変更できるようにオブジェクト化
    final SortCondition sortCondition = new SortCondition(true, "name");
    // クエリ実行
    final StockQueryResult response = stockService.query(condition, sortCondition);

    return new ResponseEntity<LinkedHashMap<String, Integer>>(new StocksResponse(response).getStockMap(), HttpStatus.OK);
  }

  /** 全削除 */
  @DeleteMapping(
      produces = { "application/json" })
  @Logging
  public ResponseEntity<Object> deleteAll() {
    // 在庫、売り上げを全削除
    stockService.deleteAll();
    salesService.deleteAll();

    return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
  }
}
