package com.aws.jp.web.test.api.infrastructure;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.aws.jp.web.test.api.domain.Sales;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Entity
@Data
@Table(name = "Sales")
@NamedQueries({
    @NamedQuery(name = "deleteAllSales", query = "DELETE FROM SalesEntity s")
})
public class SalesEntity {
  // ユーザーID
  @Id
  @Column(name = "CUSTOMER_ID")
  private String customerId;

  // 売り上げ
  @Column(name = "PRICE")
  @NotNull
  private BigDecimal price;

  private SalesEntity(String customerId, BigDecimal price) {
    this.customerId = customerId;
    this.price = price;
    ValidateHelper.validate(this);
  }

  public static SalesEntity of(Sales sales) {
    return new SalesEntity(sales.getCustomerId(), sales.getPrice());
  }

  public Sales convert() {
    return new Sales(customerId, price);
  }
}
