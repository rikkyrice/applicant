package com.aws.jp.web.test.api.ui.error;

import lombok.Getter;

public class BadRequestParamsException extends RuntimeException {
  private static final long serialVersionUID = -2870980956809763545L;
  @Getter private final String message;

  public BadRequestParamsException(String message) {
    super();
    this.message = message;
  }
}
