package com.aws.jp.web.test.api.application;

import java.util.Objects;
import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.annotation.ApplicationScope;

import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.domain.StockRepository;
import com.aws.jp.web.test.api.domain.query.SortCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryResult;
import com.aws.jp.web.test.api.ui.error.BadRequestParamsException;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@ApplicationScope
@RequiredArgsConstructor
public class StocksService {
  @Inject private final StockRepository repository;

  public Stock post(final Stock stock) {
    final Stock currentStock = repository.findByName(stock.getName()).orElse(null);
    // エンティティが存在しない場合は新規に作成する
    if (Objects.isNull(currentStock)) {
      return repository.create(stock);
    }
    // すでにエンティティが存在する場合は在庫を更新する
    final Stock updatedStock = currentStock.updateAmount(currentStock.getAmount() + stock.getAmount());
    return repository.update(updatedStock);
  }

  public Stock get(final String name) {
    // 在庫を名前をキーにして取得する
    // 在庫が存在しない場合は在庫数を0とした在庫オブジェクトを返す
    final Stock stock = repository.findByName(name).orElse(new Stock(name, 0));
    return stock;
  }

  public StockQueryResult query(StockQueryCondition condition, SortCondition sortCondition) {
    // 在庫情報のクエリを実行
    final StockQueryResult result = repository.query(condition, sortCondition);
    return result;
  }

  public Stock buy(final Stock stock) {
    // 在庫がない場合は販売不可能なのでエラーを返す
    final Stock currentStock = repository.findByName(stock.getName()).orElseThrow(() -> new BadRequestParamsException("ERROR"));
    // 在庫が販売数よりも少ない場合は販売不可能なのでエラーを返す
    if (currentStock.getAmount() < stock.getAmount()) {
      throw new BadRequestParamsException("ERROR");
    }
    // 在庫を更新する
    final Stock updatedStock = currentStock.updateAmount(currentStock.getAmount() - stock.getAmount());
    return repository.update(updatedStock);
  }

  public void deleteAll() {
    // 在庫情報を全削除する
    repository.deleteAll();
  }
}
