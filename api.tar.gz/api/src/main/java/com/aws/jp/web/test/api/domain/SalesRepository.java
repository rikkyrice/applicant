package com.aws.jp.web.test.api.domain;

import java.util.Optional;

public interface SalesRepository {
  // ユーザーIDをキーに売り上げを取得
  Optional<Sales> findByCustomerId(String customerId);

  // 売り上げを作成
  Sales create(Sales sales);

  // 売り上げを更新
  Sales update(Sales sales);

  // 全削除
  void deleteAll();
}
