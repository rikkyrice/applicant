package com.aws.jp.web.test.api.domain.query;

import lombok.Getter;

@Getter
public class SortCondition {
  // 昇順でソートするかどうか
  private final boolean isAscending;

  // ソートキー
  private final String sort;

  public SortCondition(boolean isAscending, String sort) {
    this.isAscending = isAscending;
    this.sort = sort;
  }
}
