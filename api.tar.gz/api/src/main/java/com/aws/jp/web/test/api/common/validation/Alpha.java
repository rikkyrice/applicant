package com.aws.jp.web.test.api.common.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Objects;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {Alpha.AlphaNumericValidator.class})
public @interface Alpha {
  String message() default "ALPHAこのフィールドでは英字以外の値は入力できません。";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  public class AlphaNumericValidator implements ConstraintValidator<Alpha, String> {

    @Override
    public void initialize(Alpha constraintAnnotation) {
      ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
      return Objects.isNull(value) || value.matches("^[a-zA-Z]*$");
    }
  }
}
