package com.aws.jp.web.test.api.application;

import java.math.BigDecimal;
import java.util.Objects;
import javax.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.annotation.ApplicationScope;

import com.aws.jp.web.test.api.domain.Sales;
import com.aws.jp.web.test.api.domain.SalesRepository;
import com.aws.jp.web.test.api.ui.error.BadRequestParamsException;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@ApplicationScope
@RequiredArgsConstructor
public class SalesService {
  @Inject private final SalesRepository repository;

  public Sales post(final String customerId, final Integer amount, final BigDecimal price) {
    // ユーザーIDをキーにして売り上げ情報を取得する。
    // 売り上げ情報が存在しない場合はnullを返す
    final Sales currentSales = repository.findByCustomerId(customerId).orElse(null);
    final BigDecimal totalPrice = price.multiply(new BigDecimal(amount));
    // エンティティが存在しない場合は新規に作成する
    if (Objects.isNull(currentSales)) {
      return repository.create(Sales.of(customerId, totalPrice));
    }
    // すでにエンティティが存在する場合は売上を更新する
    final Sales updatedStock = currentSales.updatePrice(totalPrice.add(currentSales.getPrice()));
    return repository.update(updatedStock);
  }

  public Sales getByName(final String customerId) {
    // 売り上げがない場合はエラーを返す
    final Sales sales = repository.findByCustomerId(customerId).orElseThrow(() -> new BadRequestParamsException("ERROR"));
    return sales;
  }

  public void deleteAll() {
    // 売り上げ情報を全削除する
    repository.deleteAll();
  }
}
