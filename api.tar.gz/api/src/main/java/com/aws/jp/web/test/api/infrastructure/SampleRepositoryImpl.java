package com.aws.jp.web.test.api.infrastructure;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.annotation.ApplicationScope;

import com.aws.jp.web.test.api.domain.SampleRepository;

@Repository
@ApplicationScope
public class SampleRepositoryImpl implements SampleRepository {
  @Autowired private EntityManagerFactory factory;
  private final String sql = "SELECT COUNT(s.name) FROM StockEntity s";

  @Override
  public void touchToRepository() {
    final EntityManager manager = getEntityManager();
    final Query query = manager.createQuery(sql);
    query.getSingleResult();
  }

  public EntityManager getEntityManager() {
    return factory.createEntityManager();
  }
}
