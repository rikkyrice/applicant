package com.aws.jp.web.test.api.ui.stocks;

import java.util.LinkedHashMap;
import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.domain.query.StockQueryResult;

import lombok.Getter;

@Getter
public class StocksResponse {
  // レスポンスの仕様がmapであり、かつソート要件を満たすためLinkedHashMapを定義
  @NotNull private final LinkedHashMap<String, Integer> stockMap;
  
  public StocksResponse(StockQueryResult result) {
    final LinkedHashMap<String, Integer> stockMap = new LinkedHashMap<>();
    result.getStocks().stream().forEach(s -> stockMap.put(s.getName(), s.getAmount()));;
    this.stockMap = stockMap;
    ValidateHelper.validate(this);
  }

  public StocksResponse(Stock stock) {
    final LinkedHashMap<String, Integer> stockMap = new LinkedHashMap<>();
    stockMap.put(stock.getName(), stock.getAmount());
    this.stockMap = stockMap;
    ValidateHelper.validate(this);
  }
}
