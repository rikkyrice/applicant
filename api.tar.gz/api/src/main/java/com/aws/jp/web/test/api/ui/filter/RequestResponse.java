package com.aws.jp.web.test.api.ui.filter;

public enum RequestResponse {
  REQUEST,
  RESPONSE;
}
