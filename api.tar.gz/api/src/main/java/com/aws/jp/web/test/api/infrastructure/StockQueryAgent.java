package com.aws.jp.web.test.api.infrastructure;

import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.domain.query.SortCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryCondition;

public class StockQueryAgent {
  
  private final EntityManager manager;
  private final StockQueryCondition condition;
  private final SortCondition sortCondition;

  public StockQueryAgent(
      EntityManager manager,
      StockQueryCondition condition,
      SortCondition sortCondition) {
    this.manager = manager;
    this.condition = condition;
    this.sortCondition = sortCondition;
  }

  protected List<Stock> getStocks() {
    final CriteriaBuilder cb = manager.getCriteriaBuilder();
    final CriteriaQuery<StockEntity> cq = cb.createQuery(StockEntity.class);
    final Root<StockEntity> stocks = cq.from(StockEntity.class);
    
    // クエリのwhere句とorder句を作成
    cq.where(where(cb, stocks))
      .orderBy(sortCondition.isAscending()
          ? cb.asc(stocks.get(sortCondition.getSort()).as(String.class))
          : cb.desc(stocks.get(sortCondition.getSort()).as(String.class)));

    return manager
        .createQuery(cq)
        .getResultList()
        .stream()
        .map(s -> s.convert())
        .collect(Collectors.toList());
  }

  private Predicate where(CriteriaBuilder cb, Root<StockEntity> stocks) {
    final Integer min = condition.getMin().orElse(0);
    final Predicate predicate = cb.ge(stocks.get("amount"), min);
    return predicate;
  }
}
