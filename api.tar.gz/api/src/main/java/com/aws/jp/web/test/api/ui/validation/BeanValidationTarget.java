package com.aws.jp.web.test.api.ui.validation;

public interface BeanValidationTarget {}
