package com.aws.jp.web.test.api.ui.filter;

public interface LoggingHttpServletWrapper {
  LoggingContent getLoggingContent();
}
