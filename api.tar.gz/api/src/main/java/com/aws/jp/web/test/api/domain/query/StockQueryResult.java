package com.aws.jp.web.test.api.domain.query;

import java.util.List;

import com.aws.jp.web.test.api.domain.Stock;

import lombok.Getter;

@Getter
public class StockQueryResult {
  private final List<Stock> stocks;

  public StockQueryResult(List<Stock> stocks) {
    this.stocks = stocks;
  }
}
