package com.aws.jp.web.test.api.config;

import org.apache.catalina.connector.Connector;
import org.apache.coyote.ajp.AjpNio2Protocol;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class TomcatConfiguration {

  @Bean
  public WebServerFactoryCustomizer<TomcatServletWebServerFactory> servletContainer() {
    final Connector connector = new Connector("org.apache.coyote.ajp.AjpNio2Protocol");
    connector.setScheme("http");
    connector.setPort(8009);
    connector.setRedirectPort(8443);
    connector.setSecure(false);
    connector.setAllowTrace(false);
    final AjpNio2Protocol protocol = (AjpNio2Protocol) connector.getProtocolHandler();
    protocol.setSecretRequired(false);  // secretを使わない
    return factory -> factory.addAdditionalTomcatConnectors(connector);
  }
}