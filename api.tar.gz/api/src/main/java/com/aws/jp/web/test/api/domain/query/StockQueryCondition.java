package com.aws.jp.web.test.api.domain.query;

import java.util.Optional;
import lombok.Builder;

@Builder
public class StockQueryCondition {
  // 価格の最小値
  private final Integer min;

  public Optional<Integer> getMin() {
    return Optional.ofNullable(min);
  }
}
