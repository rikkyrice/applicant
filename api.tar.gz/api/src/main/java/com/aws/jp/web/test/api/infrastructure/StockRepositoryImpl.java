package com.aws.jp.web.test.api.infrastructure;

import java.util.Objects;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.web.context.annotation.ApplicationScope;

import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.domain.StockRepository;
import com.aws.jp.web.test.api.domain.query.SortCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryCondition;
import com.aws.jp.web.test.api.domain.query.StockQueryResult;

import lombok.RequiredArgsConstructor;

@Repository
@ApplicationScope
@RequiredArgsConstructor
public class StockRepositoryImpl implements StockRepository {
  @PersistenceContext private EntityManager manager;

  @Override
  public StockQueryResult query(
      StockQueryCondition condition, SortCondition pCondition) {
    final StockQueryAgent agent =
        new StockQueryAgent(manager, condition, pCondition);
    return new StockQueryResult(agent.getStocks());
  }
  
  @Override
  public Optional<Stock> findByName(String id) {
    final StockEntity stockEntity =
        manager.find(StockEntity.class, id);
    return Objects.nonNull(stockEntity) ? Optional.of(stockEntity.convert()) : Optional.empty();
  }

  @Override
  public Stock create(Stock stock) {
    final StockEntity entity = StockEntity.of(stock);
    manager.persist(entity);
    return entity.convert();
  }

  @Override
  public Stock update(Stock stock) {
    final StockEntity entity = StockEntity.of(stock);
    manager.merge(entity);
    return entity.convert();
  }

  @Override
  public void deleteAll() {
    manager.createNamedQuery("deleteAllStocks").executeUpdate();
  }
}
