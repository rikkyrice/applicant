package com.aws.jp.web.test.api.infrastructure;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.aws.jp.web.test.api.domain.Stock;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Entity
@Data
@Table(name = "Stocks")
@NamedQueries({
  @NamedQuery(name = "deleteAllStocks", query = "DELETE FROM StockEntity s")
})
public class StockEntity {
  // 商品名
  @Id
  @Column(name = "NAME")
  private String name;

  // 在庫
  @Column(name = "AMOUNT")
  @NotNull
  private int amount;

  private StockEntity(String name, int amount) {
    this.name = name;
    this.amount = amount;
    ValidateHelper.validate(this);
  }

  public static StockEntity of(Stock stock) {
    return new StockEntity(stock.getName(), stock.getAmount());
  }

  public Stock convert() {
    return new Stock(name, amount);
  }
}
