package com.aws.jp.web.test.api.infrastructure;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/** 
 * JPAのCriteria Queryを利用する為のmetamodel
 */
@SuppressWarnings({
  "PMD.StdCyclomaticComplexity",
  "PMD.ClassNamingConventions",
  "PMD.AvoidUsingVolatile",
  "PMD.LinguisticNaming",
  "PMD.TooManyFields",
  "PMD.UseUtilityClass"
})
@StaticMetamodel(StockEntity.class)
public class StockEntity_ {
  public static volatile SingularAttribute<StockEntity, String> name;
  public static volatile SingularAttribute<StockEntity, Integer> amount;
}
