package com.aws.jp.web.test.api.ui.stocks;

import java.util.Objects;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.aws.jp.web.test.api.common.validation.Alpha;
import com.aws.jp.web.test.api.domain.Stock;
import com.aws.jp.web.test.api.ui.error.BadRequestParamsException;
import com.aws.jp.web.test.api.ui.validation.BeanValidationTarget;

import lombok.Data;

@Data
public class PostStockRequestBody implements BeanValidationTarget {
  @NotNull
  @Size(max = 8, min = 1)
  @Alpha
  private String name;

  // 小数点が来たときに入力エラーとするためにDoubleで受け付ける
  @Min(1)
  private Double amount;

  public Stock convert() {
    // amountの指定がない場合は1を初期値とする。
    if (Objects.isNull(amount)) {
      return new Stock(name, 1);
    }
    // 整数でない場合はエラーとする。
    if (!(amount % 1 == 0)) {
      throw new BadRequestParamsException("ERROR");
    }
    // amountは整数値を渡す。
    return new Stock(name, amount.intValue());
  }

  public Integer getAmount() {
    // amountが存在しない場合はnullを返す
    if (Objects.isNull(amount)) {
      return null;
    }
    // 整数でない場合はエラーとする。
    if ((Objects.nonNull(amount)) && !(amount % 1 == 0)) {
      throw new BadRequestParamsException("ERROR");
    }
    return amount.intValue();
  }
}
