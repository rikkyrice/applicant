package com.aws.jp.web.test.api.ui.validation;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.aws.jp.web.test.api.ui.error.BadRequestParamsException;

public final class BeanValidateHelper {
  private static final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
  private static final Validator validator = factory.getValidator();

  private BeanValidateHelper() {}

  /** Validation Beanによる各項目の検証を行う */
  public static void validate(final BeanValidationTarget... targets) {
    final Set<ConstraintViolation<BeanValidationTarget>> violations = new HashSet<>();
    for (final BeanValidationTarget target : targets) {
      if (Objects.nonNull(target)) {
        // Bean Validationのvalidateを実行
        violations.addAll(validator.validate(target));
      }
    }
    // 問題がある場合はBadRequestParamsExceptionをthrow
    if (!violations.isEmpty()) {
      throw new BadRequestParamsException("ERROR");
    }
  }
}
