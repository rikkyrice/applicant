package com.aws.jp.web.test.api.domain;

public interface SampleRepository {
  void touchToRepository();
}
