package com.aws.jp.web.test.api.ui.stocks;

import javax.validation.constraints.NotNull;

import com.aws.jp.web.test.api.common.validation.ValidateHelper;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;

@Getter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class PostStockResponse {
  @NotNull private final String name;

  private final Integer amount;

  public PostStockResponse(String name, Integer amount) {
    this.name = name;
    this.amount = amount;
    ValidateHelper.validate(this);
  }
}
