package com.aws.jp.web.test.api.domain;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.aws.jp.web.test.api.common.validation.Alpha;
import com.aws.jp.web.test.api.common.validation.ValidateHelper;

import lombok.Getter;

@Getter
public class Stock {
  // 商品名
  @NotNull
  @Size(max = 8)
  @Alpha
  private final String name;

  // 在庫
  @NotNull
  @Min(0)
  private final Integer amount;

  public Stock(String name, Integer amount) {
    this.name = name;
    this.amount = amount;
    ValidateHelper.validate(this);
  }

  /** 在庫を更新した新しいオブジェクを返却 */
  public Stock updateAmount(Integer amount) {
    return new Stock(this.name, amount);
  }
}
