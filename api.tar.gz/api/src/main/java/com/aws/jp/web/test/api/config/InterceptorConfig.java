package com.aws.jp.web.test.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aws.jp.web.test.api.common.log.LoggingInterceptor;

@Configuration
public class InterceptorConfig {

  @Bean
  public LoggingInterceptor loggingInterceptor() {
    return new LoggingInterceptor();
  }
}
