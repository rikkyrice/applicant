package com.aws.jp.web.test.api.ui.error;

import javax.json.bind.annotation.JsonbProperty;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.aws.jp.web.test.api.common.config.Properties;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@EqualsAndHashCode
@AllArgsConstructor
@ToString
public final class ErrorResponse {

  @Setter
  @Getter
  @JsonbProperty("message")
  private String message;

  private ErrorResponse() {};

  @SuppressWarnings("PMD.ShortMethodName")
  public static ErrorResponse of(String message) {
    final ErrorResponse response = new ErrorResponse();
    response.setMessage(message);
    return response;
  }

  public static ResponseEntity<ErrorResponse> build(String code) {
    final int statusCode = Properties.API_ERRORCODE.getValueInt(code, 0);
    final String message = Properties.API_ERRORCODE.getValue(code, 1);
    return new ResponseEntity<ErrorResponse>(of(message), HttpStatus.valueOf(statusCode));
  }
}

