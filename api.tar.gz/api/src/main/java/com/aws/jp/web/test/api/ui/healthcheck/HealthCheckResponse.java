package com.aws.jp.web.test.api.ui.healthcheck;

import lombok.Getter;

@Getter
public class HealthCheckResponse {
  private final String message;

  public HealthCheckResponse(String message) {
    this.message = message;
  }
}
